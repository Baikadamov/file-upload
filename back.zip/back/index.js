const express = require('express');
const fs = require("fs");
const { google } = require("googleapis");
const multer = require('multer');
const cors =require('cors')
const apikeys = require("./apikey.json");


const app = express();
app.use(cors());
const SCOPE = ["https://www.googleapis.com/auth/drive"];

const upload = multer({ dest: 'uploads/' });  

async function authorize() {
  const jwtClient = new google.auth.JWT(
    apikeys.client_email,
    null,
    apikeys.private_key,
    SCOPE
  );
  await jwtClient.authorize();
  return jwtClient;
}

async function uploadFile(authClient, fileName, fileStream) {
  return new Promise((resolve, reject) => {
    const drive = google.drive({ version: "v3", auth: authClient });

    let fileMetaData = {
      name: fileName,
      parents: ["13FVXoT_EYDwZiVcOl-gTjPOgi9JyhQSg"],
    };

    drive.files.create(
      {
        resource: fileMetaData,
        media: {
          body: fileStream,
          mimeType: "text/plain",  
        },
        fields: "id",
      },
      function (error, file) {
        if (error) {
          return reject(error);
        }
        resolve(file);
      }
    );
  });
}

app.post('/upload', upload.single('file'), async (req, res) => {
  try {
    const authClient = await authorize();
    const fileName = req.file.originalname;
    const fileStream = fs.createReadStream(req.file.path);
    const uploadedFile = await uploadFile(authClient, fileName, fileStream);
    res.json(uploadedFile);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/download/:fileId', async (req, res) => {
  try {
    const authClient = await authorize();
    const fileId = req.params.fileId;
    const drive = google.drive({ version: "v3", auth: authClient });
    const file = await drive.files.get({ fileId, alt: 'media' }, { responseType: 'stream' });
    
    res.setHeader('Content-disposition', `attachment; filename=${file.data.name}`);
    res.setHeader('Content-Type', file.data.mimeType);
    
    file.data.data.pipe(res);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
